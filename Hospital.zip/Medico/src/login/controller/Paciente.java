
package login.controller;

public interface Paciente {
    

    public Paciente p1(String cpf, String telefone, String nome, String doenca, String senha);

}
