package login.controller;

import javax.swing.JOptionPane;

public class PacienteConc implements Paciente {

    private String cpf;
    private String telefone;
    private String nome;
    private String doenca;
    private String senha;
    BancoArray banco = new BancoArray();
    
    public PacienteConc(String cpf, String telefone, String nome, String doenca, String senha) {
        this.cpf = cpf;
        this.telefone = telefone;
        this.nome = nome;
        this.doenca = doenca;
        this.senha = senha;
    }
    
    //Sobrescrita de Método
    public PacienteConc consultar(String cpf) {
    try {
        banco.consultar(nome);
    } catch (Exception e) {
        
        JOptionPane.showMessageDialog(null, "Paciente não encontrado!");
        return null;
    }
        return null;
}

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDoenca() {
        return doenca;
    }

    public void setDoenca(String doenca) {
        this.doenca = doenca;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public Paciente p1(String cpf, String telefone, String nome, String doenca, String senha) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
